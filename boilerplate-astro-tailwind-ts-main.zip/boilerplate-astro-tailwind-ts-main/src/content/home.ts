export const home = {
  hero: {
    eyebrow: "Lorem ipsum",
    title: "Lorem ipsum dolor sit amet consectetur adipiscing.",
    subtitle:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.",
    primaryCta: { label: "Lorem ipsum", href: "/contact" },
    secondaryCta: { label: "Dolor sit", href: "/about" },
  },

  intro: {
    title: "Lorem ipsum dolor sit amet consectetur.",
    body: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation.",
  },

  features: {
    title: "Lorem ipsum dolor",
    items: [
      {
        title: "Lorem ipsum",
        description:
          "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore.",
        icon: "sparkles",
      },
      {
        title: "Dolor sit amet",
        description:
          "Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo.",
        icon: "layers",
      },
      {
        title: "Consectetur elit",
        description:
          "Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.",
        icon: "type",
      },
      {
        title: "Adipiscing nunc",
        description:
          "Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim.",
        icon: "zap",
      },
    ],
  },

  cta: {
    title: "Lorem ipsum dolor sit amet?",
    body: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt.",
    action: { label: "Lorem ipsum", href: "/contact" },
  },
} as const;

export type Home = typeof home;
